#!/usr/bin/env python
#
# preminder.py
# A reminder using GTK shaped windows
# http://mornie.org/blog/2007/04/26/A-reminder-using-GTK-shaped-window/
#
# Copyright (C) 2007 Daniele Tricoli aka Eriol <eriol@mornie.org>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
#
# The original pizza image (published under GNU Free Documentation License)
# was downloaded from: http://commons.wikimedia.org/wiki/Image:Spinach_pizza.jpg
# And was modified by me with Gimp :)

import pygtk
pygtk.require('2.0')

import gobject
import gtk
import pango

from datetime import datetime, time
from time import sleep

from dateutil import rrule

IMAGE_FILE = 'pizza.png'
START_CHECK_HOUR = time(9, 0)
FINISH_CHECK_HOUR = time(21, 0)
TOTAL_HOURS = FINISH_CHECK_HOUR.hour - START_CHECK_HOUR.hour
AUTO_HIDE_AFTER = 10 # seconds
CHECK_TIMER = 10 #seconds
DIPLAYING_TEXT = 'Today is a PPP/PHP Day!'

def u(t):
    if t < 0: return 0
    else: return 1

def setTimer(t):
    return u(t) - 0.5 * u(t-TOTAL_HOURS-3) - 0.25 * u(t-TOTAL_HOURS-1)

class PReminder:

    def __init__(self):
        self.window = gtk.Window(gtk.WINDOW_POPUP)
        self.window.set_events(self.window.get_events() | gtk.gdk.BUTTON_PRESS_MASK)
        self.window.connect("button_press_event", self.hide)

        self.timerShow = None
        self.pieces = 0

        colormap = gtk.gdk.colormap_get_system()
        black = colormap.alloc_color('black')
        white = colormap.alloc_color('white')

        image = gtk.Image()
        image.set_from_file(IMAGE_FILE)

        pixbuf = image.get_pixbuf()
        self.width, self.height = pixbuf.get_width(), pixbuf.get_height()
        self.pixelpiece = self.width / TOTAL_HOURS
        self.pixmap, self.mask = pixbuf.render_pixmap_and_mask()

        self.bgc = self.pixmap.new_gc(foreground=black)
        self.wgc = self.pixmap.new_gc(foreground=white)
        self.wmgc = self.mask.new_gc(foreground=white)
        self.bmgc = self.mask.new_gc(foreground=black)

        area = gtk.DrawingArea()
        self.pangolayout = area.create_pango_layout('')

        self.draw()

        self.fixed = gtk.Fixed()
        self.fixed.set_size_request(self.width, self.height)
        self.fixed.put(self.image, 0, 0)
        self.window.add(self.fixed)

        self.window.set_position(gtk.WIN_POS_CENTER_ALWAYS)

        self.check()

    def setText(self, text):
        markup = '<span size="xx-large" foreground="black">%s</span>'
        self.pangolayout.set_markup(markup % text)
        self.draw()

    def setPiece(self, x):
        self.pieces = x
        self.draw()

    def draw(self):
        w = self.width, self.pangolayout.get_pixel_size()[0]
        offset = (max(w) - min(w)) / 2.

        if self.width < self.pangolayout.get_pixel_size()[0]:
            offset = -offset

        self.mask.draw_rectangle(self.bmgc,
                                 True,
                                 0, 0,
                                 self.pieces * self.pixelpiece,
                                 self.height)
        textwidth = self.pangolayout.get_pixel_size()[0]
        self.pixmap.draw_layout(self.bgc,
                                int(offset),
                                int(self.height / 2.),
                                self.pangolayout)
        self.mask.draw_layout(self.wmgc,
                              int(offset),
                              int(self.height / 2.),
                              self.pangolayout)

        self.image = gtk.Image()
        self.image.set_from_pixmap(self.pixmap, self.mask)
        self.image.show()

        self.window.shape_combine_mask(self.mask, 0, 0)

    def hide(self, *args):
        self.window.hide()
        if self.timerShow:
            gobject.source_remove(self.timerShow)

    def show(self):
        self.window.show()
        self.fixed.show()

    def check(self):
        today = datetime.today()
        lastThursday = rrule.rrule(rrule.MONTHLY,
                                   byweekday=rrule.TH(-1),
                                   count=1)[0].date()

        if today.date() == lastThursday:
            now = today.time()
            if START_CHECK_HOUR <= now <= FINISH_CHECK_HOUR:
                timerModulator = setTimer(now.hour - START_CHECK_HOUR.hour)
                timer = int(timerModulator * 60 * 60 * 1000)
                self.setText(DIPLAYING_TEXT)
                self.setPiece(now.hour - START_CHECK_HOUR.hour)

                self.show()
                self.timerShow = gobject.timeout_add(AUTO_HIDE_AFTER * 1000,
                                                     self.hide)
        else:
            timer = CHECK_TIMER * 1000

        self.timerID = gobject.timeout_add(timer, self.check)

    def main(self):
        gtk.main()

if __name__ == "__main__":
    x = PReminder()
    try:
        x.main()
    except KeyboardInterrupt:
        lambda: 0
